module golang

go 1.25.6

require (
	github.com/golang-migrate/migrate/v4 v4.19.1 
	github.com/jmoiron/sqlx v1.4.0 
	github.com/lib/pq v1.11.2
)
